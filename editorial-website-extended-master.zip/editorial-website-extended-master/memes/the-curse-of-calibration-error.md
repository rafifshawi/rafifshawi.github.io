---
layout: imageviewer
title: The curse of calibration error
image: assets/images/memes/jpg/the-curse-of-calibration-error.jpg
image-webp: assets/images/memes/webp/the-curse-of-calibration-error.webp
image-thumb: assets/images/memes/thumb/the-curse-of-calibration-error-thumb.jpg
page-level: memepage
permalink: memes/the-curse-of-calibration-error/
robots: noindex
sitemap: false
---
