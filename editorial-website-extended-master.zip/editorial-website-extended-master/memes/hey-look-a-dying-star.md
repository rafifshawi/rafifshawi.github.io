---
layout: imageviewer
title: Hey look a dying star
image: assets/images/memes/jpg/hey-look-a-dying-star.jpg
image-webp: assets/images/memes/webp/hey-look-a-dying-star.webp
image-thumb: assets/images/memes/thumb/hey-look-a-dying-star-thumb.jpg
page-level: memepage
permalink: memes/hey-look-a-dying-star/
robots: noindex
sitemap: false
---
